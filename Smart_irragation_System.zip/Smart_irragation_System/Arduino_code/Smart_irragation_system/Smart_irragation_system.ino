#include <SoftwareSerial.h>

// SIM800L connections: TX = D8, RX = D7
#define SIM800_TX 8
#define SIM800_RX 7

SoftwareSerial sim800(SIM800_TX, SIM800_RX);

void setup() {
  Serial.begin(9600);
  sim800.begin(9600);
  delay(1000);

  // Basic initialization
  sendCommand("AT");
  sendCommand("AT+CPIN?");             // Check SIM card
  sendCommand("AT+CREG?");             // Check network registration

  // GPRS setup
  sendCommand("AT+CIPSHUT");           // Reset GPRS
  delay(500);
  sendCommand("AT+SAPBR=3,1,"Contype","GPRS"");
  sendCommand("AT+SAPBR=3,1,"APN","your_apn""); // Replace "your_apn"
  sendCommand("AT+SAPBR=1,1");         // Open GPRS context
  delay(2000);
  sendCommand("AT+SAPBR=2,1");         // Query GPRS context

  // HTTP initialization
  sendCommand("AT+HTTPINIT");
  sendCommand("AT+HTTPPARA="CID",1");
  sendCommand("AT+HTTPPARA="URL","http://example.com/data""); 
  // Replace with your URL
  sendCommand("AT+HTTPPARA="CONTENT","application/x-www-form-urlencoded"");

  // Prepare POST data
  String data = "sensor=SIM800L&value=123"; // Example data
  sim800.print("AT+HTTPDATA=");
  sim800.print(data.length());
  sim800.println(",10000");
  delay(1000);
  sim800.print(data);
  delay(2000);

  // Start POST
  sendCommand("AT+HTTPACTION=1");
  delay(6000);
  sendCommand("AT+HTTPREAD");
  sendCommand("AT+HTTPTERM");
}

void loop() {
  // Nothing to do in loop
}

void sendCommand(String cmd) {
  sim800.println(cmd);
  delay(1000);
  while (sim800.available()) {
    Serial.write(sim800.read());
  }
}
