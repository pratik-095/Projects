#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <Servo.h>

#define ssid "K50i"
#define pass "1234567890"

#define HOST "west-1f3c4-default-rtdb.firebaseio.com"
#define AUTH "mV7jJszplzNogKE4ADXLKbCkEwKDw333Eli3tfx8"

// id concists of village name , street name and dustbin no
#define id "KOGBZ01"

#define servo_motor D2
#define IR D3

#define trig D6
#define echo D7

Servo s;
FirebaseData fbdo;
FirebaseAuth auth;
FirebaseConfig config;

void readDistance(){
  digitalWrite(trig, LOW);
  delayMicroseconds(4);
  digitalWrite(trig, HIGH);
  delayMicroseconds(10);
  digitalWrite(trig, LOW);

  long t = pulseInLong(echo, HIGH);
  int distance = t*0.034/2;


  // Calculation according to dustbin lengnth

  int dustbin_lengnth = 40;
  float dustbin_per = ((float)distance/dustbin_lengnth) * 100;

  if(dustbin_per >= 80){
    Firebase.setBool(fbdo,"/KOGBZ01/Status",true);
  }
  else if(dustbin_per < 80){
    Firebase.setBool(fbdo,"/KOGBZ01/Status",false);
  }
  else{
    Serial.println(fbdo.errorReason());
  }


  if(Firebase.setFloat(fbdo,"/KOGBZ01/Percentage",dustbin_per)){
    Serial.println("Data is Uploaded Succesfully");
  }
  else{
    Serial.println(fbdo.errorReason());
  }
}

void setup() {

  Serial.begin(9600);
  pinMode(servo_motor, OUTPUT);
  pinMode(trig, OUTPUT);
  pinMode(echo, INPUT);
  s.attach(servo_motor);
  s.write(0);

  WiFi.begin(ssid,pass);
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(2000);
  }
  Serial.println("Connected!!!");


  config.host = HOST;
  config.signer.tokens.legacy_token = AUTH;

  Firebase.begin(&config, &auth);
  Firebase.reconnectWiFi(true);
}

void loop() {
  int IRstatus = digitalRead(IR);
  int temp = 0;

  if(IRstatus == 0){
    temp=1;
  }
  switch (temp) {
  case 1:
      s.write(90);
      Serial.println("Dustbbin is Opened\n");
      delay(5000);
      temp = 0;
      break;
  case 0:
      s.write(0);
      Serial.println("Dustbin is Closed\n");
      readDistance();
      delay(200);
      break;   
  }
  
  
  
}
